
public class PerKmRental {


	private static final double	PER_KM_RENTAL_COST	= 1;
	private double kilometers;
	
	//SS constructor to set the number of kilometers for this rental to 0
	public PerKmRental()
	{
		this.kilometers = 0;
	}
	//SS sets last rental kms to the total number of kms travelled
	public void newRental(double kms)
	{
		this.kilometers = kms;
	}
	//SS calculates the profit for the current kms trvelled with the rental car
	public double getProfit()
	{
		return (kilometers * PER_KM_RENTAL_COST);
	}
}
