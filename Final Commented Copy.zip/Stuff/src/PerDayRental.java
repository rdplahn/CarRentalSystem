
public class PerDayRental {


	private static final double	PER_DAY_RENTAL_COST	= 100;
	private int days;
	
	//SS constructor to set the number of rental days to 0
	public PerDayRental()
	{
		this.days = 0;
	}
	//SS sets old rental days to the total number of days te car is rented
	public void newRental(double kilometers, int days)
	{
		this.days = days;
	}
	//SS calculates the profit for the current rental of the car
	public double getProfit()
	{
		return (days * PER_DAY_RENTAL_COST);
	}
	
	
}
