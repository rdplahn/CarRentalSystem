
public class Service {
	private static final int	SERVICE_KILOMETER_LIMIT	= 100;
	private double kmSinceService;
	
	public Service()
	{
		kmSinceService = 0;
	}
	
	public boolean dueForService()
	{
		if(kmSinceService >= SERVICE_KILOMETER_LIMIT)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void addKilometers(double kilometers)
	{
		kmSinceService = kmSinceService + kilometers;
	}
	
	public void serviceVehicle()
	{
		kmSinceService = 0;
		System.out.println("Vehicle serviced.");
		System.out.println("\n\n");
	}

}
