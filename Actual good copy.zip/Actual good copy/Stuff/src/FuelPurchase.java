
public class FuelPurchase {
	private double	fuelEconomy;

	// AK a simple class, stores a value and does little else.
	//this value can be set and get.

	
	public FuelPurchase(double fuelEconomy) {
		this.fuelEconomy = fuelEconomy;
	}

	public double getFuelEconomy() {
		return fuelEconomy;
	}

	public void setFuelEconomy(double fuelEconomy) {
		this.fuelEconomy = fuelEconomy;
	}
}
